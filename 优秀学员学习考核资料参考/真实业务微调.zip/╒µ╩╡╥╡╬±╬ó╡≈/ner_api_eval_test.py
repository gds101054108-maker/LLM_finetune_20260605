import argparse
import json
import os
from collections import Counter

from ner_utils import (
    ENTITY_FIELDS,
    build_messages,
    extract_json,
    normalize_result,
    parse_expected,
    score_results,
)


def chat_completion(
    api_base: str, api_key: str, model: str, messages: list[dict[str, str]], timeout: int
) -> str:
    import requests

    response = requests.post(
        f"{api_base.rstrip('/')}/chat/completions",
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        json={
            "model": model,
            "messages": messages,
            "temperature": 0,
            "max_tokens": 512,
            "stream": False,
        },
        timeout=timeout,
    )
    response.raise_for_status()
    return response.json()["choices"][0]["message"]["content"]


def main() -> None:
    parser = argparse.ArgumentParser(description="OpenAI 兼容接口地址 NER 批量评估")
    parser.add_argument("--api-base", default=os.getenv("API_BASE", "http://127.0.0.1:8000/v1"))
    parser.add_argument("--api-key", default=os.getenv("API_KEY", ""))
    parser.add_argument("--model", default=os.getenv("MODEL_NAME", "ner-model"))
    parser.add_argument("--data", default="data/ner_test_100.json")
    parser.add_argument("--bad-cases", default="api_bad_cases.json")
    parser.add_argument("--timeout", type=int, default=120)
    args = parser.parse_args()

    from tqdm import tqdm

    with open(args.data, encoding="utf-8") as file:
        test_data = json.load(file)
    hits = Counter()
    exact_count = 0
    bad_cases = []
    for index, sample in enumerate(tqdm(test_data, desc="接口评估中")):
        expected = parse_expected(sample)
        try:
            response = chat_completion(
                args.api_base, args.api_key, args.model, build_messages(sample), args.timeout
            )
            predicted = normalize_result(extract_json(response))
            field_hits, exact = score_results(expected, predicted)
            hits.update(field_hits)
            exact_count += int(exact)
            if not exact:
                bad_cases.append({"index": index, "expected": expected, "predicted": predicted})
        except Exception as error:
            bad_cases.append({"index": index, "expected": expected, "error": str(error)})

    sample_count = len(test_data)
    field_total = sample_count * len(ENTITY_FIELDS)
    print(f"样本完全匹配率: {exact_count / sample_count:.2%} ({exact_count}/{sample_count})")
    print(f"实体字段准确率: {sum(hits.values()) / field_total:.2%} ({sum(hits.values())}/{field_total})")
    for field in ENTITY_FIELDS:
        print(f"{field}: {hits[field] / sample_count:.2%} ({hits[field]}/{sample_count})")
    with open(args.bad_cases, "w", encoding="utf-8") as file:
        json.dump(bad_cases, file, ensure_ascii=False, indent=2)
    print(f"错误案例已保存到 {args.bad_cases}，共 {len(bad_cases)} 条")


if __name__ == "__main__":
    main()
