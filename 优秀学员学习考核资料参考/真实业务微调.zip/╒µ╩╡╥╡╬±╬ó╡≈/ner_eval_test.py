import argparse
import json
from collections import Counter

from ner_utils import (
    ENTITY_FIELDS,
    build_messages,
    extract_json,
    normalize_result,
    parse_expected,
    score_results,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="地址 NER 本地模型批量评估")
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--data", default="data/ner_test_100.json")
    parser.add_argument("--bad-cases", default="bad_cases.json")
    parser.add_argument("--max-new-tokens", type=int, default=512)
    args = parser.parse_args()

    import torch
    from tqdm import tqdm
    from transformers import AutoModelForCausalLM, AutoTokenizer

    with open(args.data, encoding="utf-8") as file:
        test_data = json.load(file)
    tokenizer = AutoTokenizer.from_pretrained(args.model_path)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(args.model_path, device_map="auto")
    model.eval()

    hits = Counter()
    exact_count = 0
    bad_cases = []
    for index, sample in enumerate(tqdm(test_data, desc="评估中")):
        expected = parse_expected(sample)
        try:
            text = tokenizer.apply_chat_template(
                build_messages(sample), tokenize=False, add_generation_prompt=True
            )
            inputs = tokenizer([text], return_tensors="pt").to(model.device)
            with torch.no_grad():
                outputs = model.generate(
                    **inputs,
                    max_new_tokens=args.max_new_tokens,
                    do_sample=False,
                    pad_token_id=tokenizer.pad_token_id,
                )
            response = tokenizer.decode(
                outputs[0, inputs.input_ids.shape[1]:], skip_special_tokens=True
            )
            predicted = normalize_result(extract_json(response))
            field_hits, exact = score_results(expected, predicted)
            hits.update(field_hits)
            exact_count += int(exact)
            if not exact:
                bad_cases.append({"index": index, "expected": expected, "predicted": predicted})
        except Exception as error:
            bad_cases.append({"index": index, "expected": expected, "error": str(error)})

    sample_count = len(test_data)
    field_total = sample_count * len(ENTITY_FIELDS)
    print(f"\n样本完全匹配率: {exact_count / sample_count:.2%} ({exact_count}/{sample_count})")
    print(f"实体字段准确率: {sum(hits.values()) / field_total:.2%} ({sum(hits.values())}/{field_total})")
    for field in ENTITY_FIELDS:
        print(f"{field}: {hits[field] / sample_count:.2%} ({hits[field]}/{sample_count})")
    with open(args.bad_cases, "w", encoding="utf-8") as file:
        json.dump(bad_cases, file, ensure_ascii=False, indent=2)
    print(f"错误案例已保存到 {args.bad_cases}，共 {len(bad_cases)} 条")


if __name__ == "__main__":
    main()
