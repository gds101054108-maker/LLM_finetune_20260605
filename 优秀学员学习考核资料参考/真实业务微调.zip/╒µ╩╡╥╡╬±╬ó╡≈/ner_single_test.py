import argparse
import json

from ner_utils import build_messages, extract_json, normalize_result, parse_expected


def main() -> None:
    parser = argparse.ArgumentParser(description="单条地址 NER 本地模型测试")
    parser.add_argument("--model-path", required=True, help="合并后的本地模型路径")
    parser.add_argument("--data", default="data/ner_test_100.json")
    parser.add_argument("--index", type=int, default=0, help="测试样本下标")
    parser.add_argument("--max-new-tokens", type=int, default=512)
    args = parser.parse_args()

    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    with open(args.data, encoding="utf-8") as file:
        sample = json.load(file)[args.index]

    tokenizer = AutoTokenizer.from_pretrained(args.model_path)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(args.model_path, device_map="auto")
    model.eval()

    text = tokenizer.apply_chat_template(
        build_messages(sample), tokenize=False, add_generation_prompt=True
    )
    inputs = tokenizer([text], return_tensors="pt").to(model.device)
    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=args.max_new_tokens,
            do_sample=False,
            pad_token_id=tokenizer.pad_token_id,
        )
    response = tokenizer.decode(
        outputs[0, inputs.input_ids.shape[1]:], skip_special_tokens=True
    )
    predicted = normalize_result(extract_json(response))
    expected = parse_expected(sample)
    print("模型输出:")
    print(json.dumps({"result": predicted}, ensure_ascii=False, indent=2))
    print("\n预期输出:")
    print(json.dumps({"result": expected}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
