import json
import re
from typing import Any

ENTITY_FIELDS = [
    "regionName",
    "town",
    "streetCross",
    "pointAddress",
    "community",
    "org",
    "landMark",
    "county",
    "road",
]


def extract_json(text: str) -> dict[str, Any]:
    """Extract the first decodable JSON object from a model response."""
    fenced = re.search(r"```(?:json)?\s*(.*?)\s*```", text, re.DOTALL | re.IGNORECASE)
    candidate = fenced.group(1).strip() if fenced else text.strip()
    decoder = json.JSONDecoder()
    for index, char in enumerate(candidate):
        if char != "{":
            continue
        try:
            value, _ = decoder.raw_decode(candidate[index:])
            if isinstance(value, dict):
                return value
        except json.JSONDecodeError:
            continue
    raise ValueError(f"模型输出中未找到合法 JSON 对象: {text[:200]!r}")


def normalize_result(payload: dict[str, Any]) -> list[dict[str, str]]:
    results = payload.get("result")
    if not isinstance(results, list):
        raise ValueError("JSON 顶层必须包含数组字段 result")
    normalized = []
    for item in results:
        if not isinstance(item, dict):
            raise ValueError("result 中每个元素必须是对象")
        normalized.append({
            "id": str(item.get("id", "")),
            **{field: str(item.get(field, "") or "") for field in ENTITY_FIELDS},
        })
    return normalized


def parse_expected(sample: dict[str, str]) -> list[dict[str, str]]:
    return normalize_result(json.loads(sample["output"]))


def score_results(
    expected: list[dict[str, str]], predicted: list[dict[str, str]]
) -> tuple[dict[str, int], bool]:
    predicted_by_id = {item["id"]: item for item in predicted}
    field_hits = {field: 0 for field in ENTITY_FIELDS}
    exact = len(expected) == len(predicted)
    for truth in expected:
        guess = predicted_by_id.get(truth["id"], {})
        for field in ENTITY_FIELDS:
            hit = guess.get(field, "") == truth[field]
            field_hits[field] += int(hit)
            exact = exact and hit
    return field_hits, exact


def build_messages(sample: dict[str, str]) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": sample["instruction"]},
        {"role": "user", "content": sample["input"]},
    ]
